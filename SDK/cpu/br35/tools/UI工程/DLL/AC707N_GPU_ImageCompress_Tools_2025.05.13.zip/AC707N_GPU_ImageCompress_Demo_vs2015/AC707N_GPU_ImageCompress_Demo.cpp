// AC707N_GPU_ImageCompress_Demo.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <windows.h>
#include "AC707N_GPU_ImageCompress.h"


int main()
{
	FILE *fp = NULL;
	errno_t err;
	struct OutputImage *compress_info;
	TCHAR *src_fname_0 = L"icon_RGB565_104x104.bin";
	TCHAR *dst_fname_0 = L"icon_RGB565_104x104.out";
	TCHAR *src_fname_1 = L"Menu_10heart_rate.png";
	TCHAR *dst_fname_1 = L"Menu_10heart_rate.out";

	char *version = ac707n_image_version();
	printf("version : %s\n", version);

	err = _wfopen_s(&fp, src_fname_0, L"rb");
	if (!fp) {
		return -1;
	}
	fseek(fp, 0, SEEK_END);
	int flen = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	unsigned char *fbuf = (unsigned char *)malloc(flen);
	int ret = fread(fbuf, 1, flen, fp);
	fclose(fp);

	// ָ��RGB���ݽ���ѹ��
	struct InputImage input_info = { 0 };
	input_info.width = 104;
	input_info.height = 104;
	input_info.pixel_format = PIXEL_IN_FMT_RGB565;
	input_info.buf = fbuf;
	input_info.len = flen;

	compress_info = ac707n_image_compress(&input_info, PIXEL_OUT_FMT_RGB565, CLUT_FMT_NONE, COMPRESS_METHOD_BEST_SPACESIZE);
	if (!compress_info) {
		enum ERROR_CODE error = ac707n_image_get_errorcode();
		printf("error : %d\n", error);
		return -1;
	}
	printf("repolution : %d x %d\n", compress_info->width, compress_info->height);
	wprintf(L"%s convert to %s\n", src_fname_0, dst_fname_0);

	err = _wfopen_s(&fp, dst_fname_0, L"wb");
	if (!fp) {
		return -1;
	}
	fwrite(compress_info->buf, 1, compress_info->len, fp);
	fclose(fp);

	ac707n_image_buff_free(compress_info);


	// ָ��ͼƬ·������ѹ��
	compress_info = ac707n_image_compress_by_path(src_fname_1, PIXEL_OUT_FMT_ARGB8888, CLUT_FMT_NONE, COMPRESS_METHOD_BEST_SPACESIZE, false);
	if (!compress_info) {
		enum ERROR_CODE error = ac707n_image_get_errorcode();
		printf("error : %d\n", error);
		return -1;
	}
	printf("repolution : %d x %d\n", compress_info->width, compress_info->height);
	wprintf(L"%s convert to %s\n", src_fname_1, dst_fname_1);

	err = _wfopen_s(&fp, dst_fname_1, L"wb");
	if (!fp) {
		return -1;
	}
	fwrite(compress_info->buf, 1, compress_info->len, fp);
	fclose(fp);

	ac707n_image_buff_free(compress_info);

    return 0;
}

